`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/24/2026 09:14:11 AM
// Design Name: 
// Module Name: toptb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:


module toptb ();

    reg clk;
    reg pbin;
    reg [15:0] physical_sw;

    wire [15:0] physical_leds;

    top_fsm_system uut (
        .clk(clk), 
        .pbin(pbin), 
        .physical_sw(physical_sw), 
        .physical_leds(physical_leds)
    );

    defparam uut.ticker.MAX_COUNT = 2;

    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin

        pbin = 0;
        physical_sw = 16'd0;

        #10;
        pbin = 1; 
        #20;
        pbin = 0; 
        #20;
        physical_sw = 16'd10; 
        
        #180; 
        physical_sw = 16'd0;
        #40;
        physical_sw = 16'd5;
        #30;
        
        pbin = 1;
        #20;
        pbin = 0;
        physical_sw = 16'd0;

        #50; 
        $finish;
    end

endmodule

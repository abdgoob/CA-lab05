`timescale 1ns / 1ps

module clock_divider (
    input wire clk_in,
    input wire rst,
    output reg clk_out
);

    parameter MAX_COUNT = 50_000_000 - 1;

    reg [25:0] count;

    always @(posedge clk_in) begin
        if (rst) begin
            count <= 26'd0;
            clk_out <= 1'b0;
        end else if (count == MAX_COUNT) begin
            count <= 26'd0;
            clk_out <= ~clk_out;
        end else begin
            count <= count + 26'd1;
        end
    end

endmodule

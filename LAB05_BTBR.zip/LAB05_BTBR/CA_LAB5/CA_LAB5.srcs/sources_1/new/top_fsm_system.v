`timescale 1ns / 1ps

module top_fsm_system (
    input wire clk,
    input wire pbin,
    input wire [15:0] physical_sw,
    output wire [15:0] physical_leds
);

    localparam IDLE = 1'b0;
    localparam COUNTDOWN = 1'b1;

    wire rst_clean;
    wire [31:0] switch_data;
    wire [31:0] led_write_data;
    wire slow_clk;

    reg state;
    reg [15:0] counter;

    assign led_write_data = {16'd0, counter};

    debouncer rst_db (
        .clk(clk),
        .pbin(pbin),
        .pbout(rst_clean)
    );

    leds switch_reader (
        .clk(clk),
        .rst(rst_clean),
        .btns(16'd0),
        .writeData(32'd0),
        .writeEnable(1'b0),
        .readEnable(1'b1),
        .memAddress(30'd0),
        .switches(physical_sw),
        .readData(switch_data)
    );

    switches led_writer (
        .clk(clk),
        .rst(rst_clean),
        .writeData(led_write_data),
        .writeEnable(1'b1),
        .readEnable(1'b0),
        .memAddress(30'd0),
        .readData(),
        .leds(physical_leds)
    );

    clock_divider ticker (
        .clk_in(clk),
        .rst(rst_clean),
        .clk_out(slow_clk)
    );

    always @(posedge slow_clk or posedge rst_clean) begin
        if (rst_clean) begin
            state <= IDLE;
            counter <= 16'd0;
        end else begin
            case (state)
                IDLE: begin
                    if (switch_data[15:0] != 16'd0) begin
                        state <= COUNTDOWN;
                        counter <= switch_data[15:0];
                    end
                end
                COUNTDOWN: begin
                    if (counter != 16'd0)
                        counter <= counter - 16'd1;
                    else
                        state <= IDLE;
                end
            endcase
        end
    end

endmodule
